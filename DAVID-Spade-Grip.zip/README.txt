Youll need 4 1/4-20 nuts and a length of 1/4-20 threaded rod about 10" long. Print 2x 'hand' and 'top' they are the top and bottom and the handles of the grip. The 'push' file was designed to be a slip fit over a milspec buffer. If you have a commercial one, stop buying Anderson. The assembly is pretty self explanatory, rod and related holes are on the passenger (right) side of the rifle. 

THIS IS CONNECTED DIRECTLY TO THE TRIGGER. UNLOAD **AND** MAKE SAFE BEFORE MOVING OR YOU **WILL** HURT YOURSELF.

Don't make me ragret making this. Licensed under the GPL, no commercial sales, no stealing my idea (cough FOSTECH cough).

Load up, point at target, and push on buffer, you'll get the hang of it after the first burst.